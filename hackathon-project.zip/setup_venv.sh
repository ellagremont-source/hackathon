#!/bin/bash
# Virtual Environment Setup Script for Hackathon Project

echo "🚀 Setting up Python Virtual Environment for Hackathon Project"
echo "============================================================="

# Check if Xcode command line tools are installed
if ! xcode-select -p &> /dev/null; then
    echo "❌ Xcode command line tools not found!"
    echo "📋 Please install them first:"
    echo "   1. Run: xcode-select --install"
    echo "   2. Complete the installation through the GUI dialog"
    echo "   3. Then run this script again"
    exit 1
fi

# Create virtual environment
echo "📦 Creating virtual environment..."
/usr/bin/python3 -m venv venv

if [ $? -ne 0 ]; then
    echo "❌ Failed to create virtual environment"
    echo "Make sure Python 3 is properly installed"
    exit 1
fi

echo "✅ Virtual environment created successfully!"

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "📈 Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "📚 Installing dependencies from requirements.txt..."
pip install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✅ All dependencies installed successfully!"
    echo ""
    echo "🎉 Virtual Environment Setup Complete!"
    echo "============================================"
    echo ""
    echo "To activate the virtual environment in the future, run:"
    echo "   source venv/bin/activate"
    echo ""
    echo "To start your hackathon project:"
    echo "   python run.py                    # Flask web app"
    echo "   python run.py --mode api         # FastAPI app"
    echo "   python run.py --mode cli         # CLI mode"
    echo ""
    echo "To deactivate the virtual environment:"
    echo "   deactivate"
else
    echo "❌ Some dependencies failed to install"
    echo "Check the error messages above and try installing individual packages"
fi
