# 🚀 Virtual Environment Setup Instructions

## Current Issue: Xcode Command Line Tools Required

The setup script can't proceed because **Xcode Command Line Tools** are required for Python development on macOS.

## 📋 Step-by-Step Solution

### 1. Install Xcode Command Line Tools

**Option A: Through Terminal (Recommended)**
```bash
xcode-select --install
```
- This will open a GUI dialog
- Click "Install" and wait (5-15 minutes depending on internet speed)
- The installation includes compilers needed for Python packages

**Option B: Through App Store**
- Install full Xcode from the App Store (larger download)
- Open Xcode once to accept license agreements

**Option C: Manual Download**
- Visit [Apple Developer Downloads](https://developer.apple.com/download/more/)
- Download "Command Line Tools for Xcode" for your macOS version
- Install the downloaded package

### 2. Verify Installation

After installation completes, verify it worked:
```bash
xcode-select --print-path
```
Should return a path like `/Applications/Xcode.app/Contents/Developer` or `/Library/Developer/CommandLineTools`

### 3. Create Virtual Environment

Once Xcode tools are installed, you can:

**Option A: Use the automated script**
```bash
./setup_venv.sh
```

**Option B: Manual setup**
```bash
# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install dependencies
pip install -r requirements.txt
```

## 🔍 Why This Is Needed

- **Python packages with C extensions** (like many in requirements.txt) need compilers
- **macOS doesn't include developer tools** by default
- **Virtual environments** use Python's build system which requires these tools

## 🎯 After Setup Complete

Once your virtual environment is ready:

```bash
# Activate virtual environment
source venv/bin/activate

# Run your project
python run.py                    # Flask web app (default)
python run.py --mode api         # FastAPI with auto-docs
python run.py --mode cli         # Command line interface

# Deactivate when done
deactivate
```

## 🆘 Troubleshooting

### If installation seems stuck:
- Cancel and retry: `xcode-select --install`
- Check Activity Monitor for "Install Command Line Developer Tools"

### If you get "xcode-select: error":
- Try: `sudo xcode-select --reset`
- Then: `xcode-select --install`

### Alternative: Use Homebrew Python
If you can't install Xcode tools, consider installing Python via Homebrew:
```bash
# Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python
brew install python

# Then create virtual environment
python3 -m venv venv
```

## ✅ What's Ready

Your hackathon project includes:
- ✅ **Flask web application** with modern UI
- ✅ **FastAPI backend** with automatic documentation  
- ✅ **CLI interface** for command-line tools
- ✅ **Pre-configured dependencies** for AI/ML, web dev, data processing
- ✅ **Professional project structure**
- ✅ **Environment configuration** ready

**Once the virtual environment is set up, you'll be ready to start building! 🎉**
