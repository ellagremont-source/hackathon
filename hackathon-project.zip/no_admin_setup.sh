#!/bin/bash
# No Administrator Access Setup for Hackathon Project

set -e

echo "🚀 No-Admin Hackathon Setup"
echo "============================"
echo ""
echo "This setup works WITHOUT administrator privileges!"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create local directory for Python installation
INSTALL_DIR="$HOME/.hackathon_python"
mkdir -p "$INSTALL_DIR"

print_status "Setting up portable Python environment in $INSTALL_DIR"

# Option 1: Try to use conda/miniconda (no sudo required)
if command -v conda >/dev/null 2>&1; then
    print_status "Found conda! Using conda for Python environment..."
    
    # Create conda environment
    conda create -y -n hackathon python=3.11
    
    # Activate conda environment
    source "$(conda info --base)/etc/profile.d/conda.sh"
    conda activate hackathon
    
    print_success "Conda environment 'hackathon' created and activated"
    
elif command -v python3 >/dev/null 2>&1; then
    # Option 2: Try with existing python3 (even with limited functionality)
    print_status "Found system Python3, attempting to create virtual environment..."
    
    # Try to create venv in user space
    python3 -m venv "$INSTALL_DIR/venv" 2>/dev/null || {
        print_error "Cannot create virtual environment with system Python3"
        print_status "Trying alternative approach..."
        
        # Alternative: Download portable Python
        print_status "Downloading portable Python installation..."
        
        # Use pyenv-installer (no sudo required)
        curl -L https://github.com/pyenv/pyenv-installer/raw/master/bin/pyenv-installer | bash
        
        # Add pyenv to PATH for this session
        export PYENV_ROOT="$HOME/.pyenv"
        export PATH="$PYENV_ROOT/bin:$PATH"
        eval "$(pyenv init --path)"
        eval "$(pyenv init -)"
        
        # Install Python with pyenv
        pyenv install 3.11.7
        pyenv global 3.11.7
        
        # Create virtual environment
        python -m venv venv
        source venv/bin/activate
        
        print_success "Pyenv Python installation complete"
    }
    
    if [[ -d "$INSTALL_DIR/venv" ]]; then
        source "$INSTALL_DIR/venv/bin/activate"
        print_success "Virtual environment activated"
    elif [[ -d "venv" ]]; then
        source venv/bin/activate  
        print_success "Local virtual environment activated"
    fi
    
else
    # Option 3: Download and install Python locally
    print_status "No Python found. Installing Python locally..."
    
    cd "$INSTALL_DIR"
    
    # Download Python source (this is a fallback - may not work without build tools)
    print_status "Attempting to download portable Python..."
    
    # Try to download pre-built Python if available
    if command -v curl >/dev/null 2>&1; then
        # This is a simplified approach - in reality, you'd need pre-built binaries
        print_error "Cannot install Python without administrator access and without existing Python"
        print_error "Please ask an administrator to install Python or Homebrew"
        exit 1
    fi
fi

# Install minimal dependencies
print_status "Installing minimal dependencies..."

# Create a minimal requirements file if the full one fails
cat > minimal_requirements.txt << EOF
flask>=2.0.0
jinja2>=3.0.0
werkzeug>=2.0.0
click>=8.0.0
markupsafe>=2.0.0
itsdangerous>=2.0.0
EOF

# Try to install dependencies
pip install --user -r minimal_requirements.txt || {
    print_status "Installing dependencies one by one..."
    pip install --user flask || print_error "Failed to install Flask"
    pip install --user requests || print_error "Failed to install requests"
}

# Test Python installation
print_status "Testing Python installation..."
python --version
pip list | head -5

# Create activation script
cat > ../activate_hackathon.sh << 'EOF'
#!/bin/bash
echo "🚀 Activating Hackathon Environment (No-Admin Setup)"

# Try different activation methods
if [[ -f "$HOME/.hackathon_python/venv/bin/activate" ]]; then
    source "$HOME/.hackathon_python/venv/bin/activate"
elif [[ -f "venv/bin/activate" ]]; then
    source venv/bin/activate
elif command -v conda >/dev/null 2>&1; then
    source "$(conda info --base)/etc/profile.d/conda.sh"
    conda activate hackathon
elif [[ -d "$HOME/.pyenv" ]]; then
    export PYENV_ROOT="$HOME/.pyenv"
    export PATH="$PYENV_ROOT/bin:$PATH"
    eval "$(pyenv init --path)"
    eval "$(pyenv init -)"
fi

echo "✅ Environment activated!"
echo "Run: python run.py"
python --version 2>/dev/null || echo "❌ Python not found"
EOF

chmod +x ../activate_hackathon.sh

print_success "Setup complete!"
echo ""
echo "🎉 Your no-admin hackathon setup is ready!"
echo ""
echo "To activate: ./activate_hackathon.sh" 
echo "To run: python run.py"
echo ""
print_status "Note: This setup has limited functionality due to no admin access"
