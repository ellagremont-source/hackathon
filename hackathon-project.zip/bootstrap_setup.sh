#!/bin/bash
# Bootstrap Setup Script for Hackathon Project
# This script doesn't require Python to be working initially!

set -e  # Exit on any error

echo "🚀 Bootstrap Setup for Hackathon Project"
echo "========================================"
echo ""
echo "This script will:"
echo "1. Install Homebrew (if needed)"
echo "2. Install Python via Homebrew" 
echo "3. Create virtual environment"
echo "4. Install all dependencies"
echo "5. Test the setup"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Step 1: Install Homebrew if not present
print_status "Checking for Homebrew..."
if command_exists brew; then
    print_success "Homebrew is already installed"
else
    print_status "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Add Homebrew to PATH for this session
    if [[ -f "/opt/homebrew/bin/brew" ]]; then
        # Apple Silicon Mac
        export PATH="/opt/homebrew/bin:$PATH"
        echo 'export PATH="/opt/homebrew/bin:$PATH"' >> ~/.zshrc
    elif [[ -f "/usr/local/bin/brew" ]]; then
        # Intel Mac
        export PATH="/usr/local/bin:$PATH"
        echo 'export PATH="/usr/local/bin:$PATH"' >> ~/.zshrc
    fi
    
    print_success "Homebrew installed successfully"
fi

# Update Homebrew
print_status "Updating Homebrew..."
brew update

# Step 2: Install Python via Homebrew
print_status "Installing Python via Homebrew..."
brew install python

# Make sure we're using Homebrew Python
if command_exists python3; then
    PYTHON_PATH=$(which python3)
    print_success "Python 3 installed at: $PYTHON_PATH"
    python3 --version
else
    print_error "Python 3 installation failed"
    exit 1
fi

# Step 3: Create virtual environment
print_status "Creating virtual environment..."
python3 -m venv venv

if [[ -d "venv" ]]; then
    print_success "Virtual environment created successfully"
else
    print_error "Failed to create virtual environment"
    exit 1
fi

# Step 4: Activate virtual environment and install dependencies
print_status "Activating virtual environment and installing dependencies..."
source venv/bin/activate

# Upgrade pip first
print_status "Upgrading pip..."
pip install --upgrade pip

# Install dependencies
print_status "Installing dependencies from requirements.txt..."
if [[ -f "requirements.txt" ]]; then
    pip install -r requirements.txt
    print_success "All dependencies installed successfully"
else
    print_warning "requirements.txt not found, creating minimal setup..."
    pip install flask fastapi uvicorn requests python-dotenv
fi

# Step 5: Test the setup
print_status "Testing the setup..."

# Test Python import
python -c "import sys; print(f'Python {sys.version} is working!')"

# Test Flask
python -c "import flask; print(f'Flask {flask.__version__} is available')" 2>/dev/null || print_warning "Flask not available"

# Test FastAPI  
python -c "import fastapi; print(f'FastAPI {fastapi.__version__} is available')" 2>/dev/null || print_warning "FastAPI not available"

# Deactivate for the final message
deactivate

# Step 6: Create activation script
print_status "Creating easy activation script..."
cat > activate_env.sh << 'EOF'
#!/bin/bash
# Activation script for your hackathon environment

echo "🚀 Activating Hackathon Environment..."
source venv/bin/activate

echo "✅ Virtual environment activated!"
echo ""
echo "Available commands:"
echo "  python run.py                    # Start Flask web app"
echo "  python run.py --mode api         # Start FastAPI app"  
echo "  python run.py --mode cli         # Run CLI mode"
echo ""
echo "To deactivate: deactivate"
echo ""

# Show Python info
python --version
pip list --format=columns | head -10
EOF

chmod +x activate_env.sh

print_success "Setup script created: activate_env.sh"

echo ""
echo "🎉 SETUP COMPLETE!"
echo "=================="
echo ""
echo "Your hackathon environment is ready! Here's how to use it:"
echo ""
echo -e "${GREEN}1. Activate the environment:${NC}"
echo "   ./activate_env.sh"
echo "   # OR manually:"
echo "   source venv/bin/activate"
echo ""
echo -e "${GREEN}2. Run your project:${NC}"
echo "   python run.py                    # Flask web app (default)"
echo "   python run.py --mode api         # FastAPI with docs"
echo "   python run.py --mode cli         # Command line interface"
echo ""
echo -e "${GREEN}3. When done:${NC}"
echo "   deactivate"
echo ""
echo -e "${BLUE}Pro tip:${NC} Visit http://localhost:8000/docs for FastAPI documentation"
echo ""
print_success "Happy hacking! 🎯"
