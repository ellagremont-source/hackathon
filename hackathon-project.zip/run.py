#!/usr/bin/env python3
"""
Hackathon Project Entry Point

This is the main entry point for your hackathon project.
You can choose to run it as a Flask web app, FastAPI app, or CLI application.
"""

import os
import sys
from pathlib import Path

# Add src directory to Python path
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

def main():
    """Main entry point for the application."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Hackathon Project")
    parser.add_argument(
        "--mode", 
        choices=["web", "api", "cli"], 
        default="web",
        help="Run mode: web (Flask), api (FastAPI), or cli"
    )
    parser.add_argument(
        "--host", 
        default="localhost",
        help="Host to run the server on"
    )
    parser.add_argument(
        "--port", 
        type=int, 
        default=8000,
        help="Port to run the server on"
    )
    
    args = parser.parse_args()
    
    if args.mode == "web":
        run_flask_app(args.host, args.port)
    elif args.mode == "api":
        run_fastapi_app(args.host, args.port)
    elif args.mode == "cli":
        run_cli_app()

def run_flask_app(host="localhost", port=8000):
    """Run the Flask web application."""
    try:
        from api.app import create_flask_app
        app = create_flask_app()
        print(f"🚀 Starting Flask app at http://{host}:{port}")
        app.run(host=host, port=port, debug=True)
    except ImportError:
        print("❌ Flask app not found. Create src/api/app.py to run in web mode.")
        sys.exit(1)

def run_fastapi_app(host="localhost", port=8000):
    """Run the FastAPI application."""
    try:
        import uvicorn
        print(f"🚀 Starting FastAPI app at http://{host}:{port}")
        uvicorn.run("api.fastapi_app:app", host=host, port=port, reload=True)
    except ImportError:
        print("❌ FastAPI app not found. Create src/api/fastapi_app.py to run in api mode.")
        sys.exit(1)

def run_cli_app():
    """Run the CLI application."""
    try:
        from cli.main import cli_main
        cli_main()
    except ImportError:
        print("❌ CLI app not found. Create src/cli/main.py to run in cli mode.")
        print("Running basic CLI demo instead...")
        print("🎉 Welcome to your hackathon project!")
        print("✨ Your codebase is ready for development!")

if __name__ == "__main__":
    main()
