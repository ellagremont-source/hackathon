#!/bin/bash
# Simple Alternative Setup (Minimal Dependencies)

echo "🚀 Simple Hackathon Setup"
echo "========================="

# Install Homebrew if needed
if ! command -v brew >/dev/null 2>&1; then
    echo "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Add to PATH
    if [[ -f "/opt/homebrew/bin/brew" ]]; then
        export PATH="/opt/homebrew/bin:$PATH"
    elif [[ -f "/usr/local/bin/brew" ]]; then
        export PATH="/usr/local/bin:$PATH"
    fi
fi

# Install Python
echo "Installing Python..."
brew install python

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv

# Create simple activation message
echo "#!/bin/bash
source venv/bin/activate
echo '✅ Environment activated! Run: python run.py'" > activate.sh
chmod +x activate.sh

echo ""
echo "✅ Setup complete!"
echo "Run: ./activate.sh"
echo "Then: python run.py"
