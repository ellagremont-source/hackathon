"""
FastAPI Application

A basic FastAPI app structure for your hackathon project.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Create FastAPI app
app = FastAPI(
    title="Hackathon API",
    description="FastAPI application for your hackathon project",
    version="1.0.0"
)

# Pydantic models
class DemoRequest(BaseModel):
    message: str
    data: Optional[Dict[str, Any]] = None

class DemoResponse(BaseModel):
    status: str
    message: str
    received_data: Optional[Dict[str, Any]] = None

# Routes
@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "message": "Welcome to your Hackathon FastAPI!",
        "endpoints": ["/", "/health", "/demo"],
        "docs": "/docs"
    }

@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy", "message": "FastAPI server is running!"}

@app.get("/demo")
async def demo_get():
    """Demo GET endpoint."""
    return {
        "message": "Hello from FastAPI!",
        "method": "GET",
        "tip": "Try POSTing to this endpoint with JSON data"
    }

@app.post("/demo", response_model=DemoResponse)
async def demo_post(request: DemoRequest):
    """Demo POST endpoint."""
    return DemoResponse(
        status="success",
        message=f"Received: {request.message}",
        received_data=request.data
    )

# Add CORS middleware if needed
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify actual origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
