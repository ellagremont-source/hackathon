"""
Flask Web Application

A basic Flask app structure for your hackathon project.
"""

from flask import Flask, render_template, jsonify, request
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def create_flask_app():
    """Create and configure the Flask application."""
    app = Flask(__name__, 
                template_folder='../../templates',
                static_folder='../../static')
    
    # Configuration
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-key-change-in-production')
    app.config['DEBUG'] = os.getenv('DEBUG', 'True').lower() == 'true'
    
    # Routes
    @app.route('/')
    def home():
        """Home page."""
        return render_template('index.html', title="Hackathon Project")
    
    @app.route('/api/health')
    def health():
        """Health check endpoint."""
        return jsonify({"status": "healthy", "message": "Server is running!"})
    
    @app.route('/api/demo', methods=['GET', 'POST'])
    def demo():
        """Demo API endpoint."""
        if request.method == 'POST':
            data = request.get_json() or {}
            return jsonify({
                "message": "Data received successfully!",
                "received_data": data,
                "method": "POST"
            })
        else:
            return jsonify({
                "message": "Hello from your hackathon API!",
                "endpoints": ["/", "/api/health", "/api/demo"],
                "method": "GET"
            })
    
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors."""
        return jsonify({"error": "Not found"}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors."""
        return jsonify({"error": "Internal server error"}), 500
    
    return app

if __name__ == '__main__':
    app = create_flask_app()
    app.run(debug=True)
