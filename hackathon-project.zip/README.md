# 🚀 Hackathon Project

Welcome to your hackathon codebase! This project is set up with both Flask and FastAPI options, along with a modern web interface.

## 🎯 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Environment Setup
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your API keys and configuration
# nano .env
```

### 3. Run the Application

#### Option A: Flask Web App (Default)
```bash
python run.py
# or
python run.py --mode web --host localhost --port 8000
```
Visit: http://localhost:8000

#### Option B: FastAPI App
```bash
python run.py --mode api
```
Visit: http://localhost:8000
API Docs: http://localhost:8000/docs

#### Option C: CLI Mode
```bash
python run.py --mode cli
```

## 📁 Project Structure

```
Hackathon/
├── run.py                 # Main entry point
├── requirements.txt       # Python dependencies
├── .env.example          # Environment variables template
├── .gitignore           # Git ignore patterns
├── README.md            # This file
├── src/                 # Source code
│   ├── api/             # API modules
│   │   ├── app.py       # Flask application
│   │   └── fastapi_app.py # FastAPI application
│   ├── models/          # Data models
│   └── utils/           # Utility functions
├── templates/           # HTML templates
│   └── index.html       # Main page
├── static/              # Static assets
│   ├── css/
│   │   └── style.css    # Custom styles
│   └── js/
│       └── app.js       # Frontend JavaScript
└── tests/               # Test files
```

## 🔧 Features Included

### ✅ Web Framework Options
- **Flask**: Traditional web application with Jinja2 templates
- **FastAPI**: Modern API with automatic docs and type hints
- **Flexible**: Switch between modes easily

### ✅ Frontend
- **Bootstrap 5**: Modern, responsive UI framework
- **Custom CSS**: Beautiful styling with CSS variables
- **Interactive JS**: API testing and real-time status

### ✅ API Endpoints
- `GET /` - Main page
- `GET /api/health` - Health check
- `GET /api/demo` - Demo endpoint
- `POST /api/demo` - Demo with data

### ✅ Development Tools
- **Environment management** with python-dotenv
- **Code formatting** with black
- **Linting** with flake8
- **Testing** with pytest

## 🎨 Customization

### Adding New API Endpoints

#### Flask (src/api/app.py)
```python
@app.route('/api/my-endpoint')
def my_endpoint():
    return jsonify({"message": "Hello!"})
```

#### FastAPI (src/api/fastapi_app.py)
```python
@app.get("/api/my-endpoint")
async def my_endpoint():
    return {"message": "Hello!"}
```

### Adding Database Models
Create your models in `src/models/`:
```python
# src/models/user.py
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(50))
```

### Environment Variables
Add your configuration to `.env`:
```bash
# API Keys
OPENAI_API_KEY=your_key_here
ANTHROPIC_API_KEY=your_key_here

# Database
DATABASE_URL=sqlite:///./hackathon.db

# App Config
DEBUG=True
SECRET_KEY=your_secret_key
```

## 🧪 Testing

```bash
# Run tests
pytest

# Run with coverage
pytest --cov=src

# Format code
black src/

# Lint code
flake8 src/
```

## 🚀 Deployment

### Local Development
```bash
python run.py --mode web --host 0.0.0.0 --port 8000
```

### Production (FastAPI)
```bash
pip install gunicorn
gunicorn src.api.fastapi_app:app -w 4 -k uvicorn.workers.UvicornWorker
```

## 📚 Common Tasks

### Adding AI/ML Features
The requirements include popular AI libraries:
- **OpenAI**: GPT models
- **Anthropic**: Claude models  
- **Transformers**: Hugging Face models
- **PyTorch**: Deep learning

### Database Setup
```python
# src/database.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

engine = create_engine(os.getenv("DATABASE_URL"))
SessionLocal = sessionmaker(bind=engine)
```

### Adding Authentication
```python
# Example Flask-Login setup
from flask_login import LoginManager, login_required

login_manager = LoginManager()
login_manager.init_app(app)
```

## 🎉 Happy Hacking!

Your codebase is ready for development. The structure is flexible and can be adapted for:
- Web applications
- REST APIs
- AI/ML projects
- Data processing tools
- And much more!

Need help? Check the `/docs` endpoint for FastAPI or explore the code structure.

---
**Built for hackathons** 💪 **Ready for innovation** 🚀
