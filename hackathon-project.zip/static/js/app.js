// Frontend JavaScript for Hackathon Project

// Check API status on page load
document.addEventListener('DOMContentLoaded', function() {
    checkAPIStatus();
});

// Check if the API is running
async function checkAPIStatus() {
    const statusElement = document.getElementById('status');
    statusElement.innerHTML = '<span class="spinner"></span> Checking API status...';
    
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        
        if (response.ok) {
            statusElement.innerHTML = `
                <div class="text-success">
                    <i class="fas fa-check-circle"></i> API is running
                    <br><small class="text-muted">${data.message}</small>
                </div>
            `;
        } else {
            throw new Error('API not responding correctly');
        }
    } catch (error) {
        statusElement.innerHTML = `
            <div class="text-warning">
                <i class="fas fa-exclamation-triangle"></i> API connection failed
                <br><small class="text-muted">Make sure the server is running</small>
            </div>
        `;
        console.error('API Status Check Error:', error);
    }
}

// Test API endpoint
async function testAPI() {
    const responseElement = document.getElementById('response');
    responseElement.innerHTML = '<span class="spinner"></span> Testing API...';
    
    try {
        const response = await fetch('/api/demo');
        const data = await response.json();
        
        responseElement.innerHTML = `
            <strong>✅ API Test Successful!</strong><br>
            <pre class="mt-2">${JSON.stringify(data, null, 2)}</pre>
        `;
        responseElement.className = 'border p-3 bg-light-success';
    } catch (error) {
        responseElement.innerHTML = `
            <strong>❌ API Test Failed</strong><br>
            <small class="text-danger">${error.message}</small>
        `;
        responseElement.className = 'border p-3 bg-light-danger';
        console.error('API Test Error:', error);
    }
}

// Send custom data to API
async function sendData() {
    const textArea = document.getElementById('testData');
    const responseElement = document.getElementById('response');
    
    let data;
    try {
        data = JSON.parse(textArea.value || '{"message": "Hello from frontend!"}');
    } catch (error) {
        responseElement.innerHTML = `
            <strong>❌ Invalid JSON</strong><br>
            <small class="text-danger">${error.message}</small>
        `;
        return;
    }
    
    responseElement.innerHTML = '<span class="spinner"></span> Sending data...';
    
    try {
        const response = await fetch('/api/demo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            responseElement.innerHTML = `
                <strong>✅ Data sent successfully!</strong><br>
                <pre class="mt-2">${JSON.stringify(result, null, 2)}</pre>
            `;
            responseElement.className = 'border p-3 bg-success bg-opacity-10';
        } else {
            throw new Error(result.error || 'Server error');
        }
    } catch (error) {
        responseElement.innerHTML = `
            <strong>❌ Failed to send data</strong><br>
            <small class="text-danger">${error.message}</small>
        `;
        responseElement.className = 'border p-3 bg-danger bg-opacity-10';
        console.error('Send Data Error:', error);
    }
}

// Show documentation
function showDocs() {
    alert('📚 Documentation Tips:\\n\\n' +
          '1. Use python run.py --mode web for Flask app\\n' +
          '2. Use python run.py --mode api for FastAPI app\\n' +
          '3. Visit /docs for FastAPI documentation\\n' +
          '4. Check the README.md for detailed setup instructions');
}

// Utility function to format timestamps
function formatTime(date) {
    return date.toLocaleTimeString('en-US', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

// Auto-refresh status every 30 seconds
setInterval(checkAPIStatus, 30000);
